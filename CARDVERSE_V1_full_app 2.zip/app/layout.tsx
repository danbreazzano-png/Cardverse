import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "CARDVERSE",
  description: "Know your card. Know your deal."
};

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}