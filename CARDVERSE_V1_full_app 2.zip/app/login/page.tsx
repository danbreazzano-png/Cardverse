 "use client";
import {useState} from "react";
import {supabaseBrowser} from "@/lib/supabase-browser";
import {useRouter} from "next/navigation";
import Link from "next/link";

export default function Login(){
 const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [signup,setSignup]=useState(false); const [msg,setMsg]=useState(""); const router=useRouter();
 async function submit(e:React.FormEvent){e.preventDefault();setMsg("Working...");const s=supabaseBrowser();let r=signup?await s.auth.signUp({email,password}):await s.auth.signInWithPassword({email,password});if(r.error)setMsg(r.error.message);else{setMsg(signup?"Check your email to confirm your account.":"Success");if(!signup)router.push("/app")}}
 return <main className="wrap"><Link href="/" className="btn">← Home</Link><div className="panel" style={{maxWidth:460,margin:"70px auto"}}><div className="eyebrow">CARDVERSE ACCOUNT</div><h1>{signup?"Create account":"Sign in"}</h1><form className="form" onSubmit={submit}><input type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required/><input type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} minLength={6} required/><button className="btn primary">{signup?"Create account":"Sign in"}</button></form><p className="muted">{msg}</p><button className="btn" onClick={()=>setSignup(!signup)}>{signup?"Already have an account? Sign in":"Need an account? Create one"}</button></div></main>
}