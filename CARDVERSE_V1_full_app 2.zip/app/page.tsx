import Link from "next/link";

export default function Home(){
 return <><header className="nav"><div className="brand"><span className="mark">CV</span>CARDVERSE</div><nav className="navlinks"><a href="#how">How it works</a><a href="#features">Features</a><a href="#pricing">Pricing</a></nav><Link className="btn primary" href="/login">Open app</Link></header>
 <main className="wrap">
  <section className="hero"><div><div className="eyebrow">THE COLLECTOR'S EDGE</div><h1>Know your card.<br/><span>Know your deal.</span></h1><p>Identify sports and TCG cards, estimate value, build a digital Card Passport, and score potential deals before you buy.</p><div className="actions"><Link className="btn primary" href="/app">Try the demo</Link><a className="btn" href="#features">Explore features</a></div></div><div className="hero-art"><div><strong>CARDVERSE</strong><small>SCAN • VALUE • COLLECT</small></div></div></section>
  <section id="features"><div className="eyebrow">CORE PRODUCT</div><h2>One app for the moments collectors care about.</h2><div className="cardgrid"><div className="panel"><div className="eyebrow">01</div><h3>AI Card Scan</h3><p className="muted">Turn a card photo into structured card information.</p></div><div className="panel"><div className="eyebrow">02</div><h3>Deal Score</h3><p className="muted">Compare an asking price with the estimated market range.</p></div><div className="panel"><div className="eyebrow">03</div><h3>Card Passport</h3><p className="muted">Keep a persistent record for each collectible.</p></div></div></section>
 </main></>
}